<!DOCTYPE html>

<?php
   //include("config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      $servername = 'localhost';
      $username = $_POST['username'];
      $password = $_POST['password']; 
      
      $conn = mysqli_connect($servername, $username, $password);
      $_SESSION['servername'] = $servername;
      $_SESSION['user'] = $username;
      $_SESSION['pass'] = $password;
      if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
      }
      else {
        $_SESSION['servername'] = $servername;
        $_SESSION['user'] = $username;
        $_SESSION['pass'] = $password;
        header("location: Database/databases.php");
      }
   }
?>

<html lang="en">

<link href="login.css" rel="stylesheet"  type="text/css">
<body>
<div class=container3>
<h1>Cloud Stack Analysis Tool</h1>
</div>
<div class="login-page">
  <div class="form">
    <!-- <form class="register-form">
      <input type="text" placeholder="name" />
      <input type="password" placeholder="password" />
      <input type="text" placeholder="email address" />
      <button>create</button>
    </form> -->
    <form class="login-form" action = "" method = "post">
      <input type="text" name = "username" placeholder="username" />
      <input type="password" name = "password" placeholder="password" />
      <input type="submit" value=" Submit"/>
		  <!-- <a href="Database/databases.html">
    <button type="button" class="loginbtn">Login</button>
	</a> -->
    </form>
  </div>
</div>
<p>
</p>
</body>
</html>


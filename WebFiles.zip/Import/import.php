<!DOCTYPE html>
<html lang="en">
<head>
<link href="normalize.css" rel="stylesheet" type="text/css">
<link href="import.css" rel="stylesheet"  type="text/css">
</head>
<body>
<header>
<a href="../Database/databases.php"><img src="../Images/cloud.png" alt="Cloud picture" height="115" width="115"></a> 
<div class="header">
  <h1>Cloud Stack Analysis Tool</h1>
</div>
</header>
<ul>
  <li><a href="../Tables/tables.php">Tables</a></li>
  <li><a href="../Queries/query.php">Queries</a></li>
  <li><a class="active" href="#import">Import</a></li>
  <li><a href="#log off">Log Off</a></li>
</ul>
<div class=container3>
<h2>Import New Data</h2>
</div>
<div class="container">
  <div class="center">
    <button>Upload File</button>
	    <button>Cancel</button>
  </div>
</div>
</body>
</html>

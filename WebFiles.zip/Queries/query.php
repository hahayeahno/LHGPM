<!DOCTYPE html>
<html lang="en">
<head>
<link href="query.css" rel="stylesheet"  type="text/css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<header>
<a href="../Database/databases.php"><img src="../Images/cloud.png" alt="Cloud picture" height="115" width="115"></a> 
<div class="header">
  <h1>Cloud Stack Analysis Tool</h1>
</div>
</header>
<ul>
  <li><a href="../Tables/tables.php">Tables</a></li>
  <li><a class="active" href="query.php">Queries</a></li>
  <li><a href="../Import/import.php">Import</a></li>
  <li><a href="#log off">Log Off</a></li>
</ul>
  <div class="container">
      <h2>Query Builder</h2>
	        <button class="button button4">Run Query</button>
			      <button class="button button4">Reset Query</button>
				  <!-- <div class="container2"> -->	
<h3>Databases</h3>
  <label class="container2">Database 1
  <input type="checkbox" checked="checked">
  <span class="checkmark"></span>
</label>

<label class="container2">Database 2
  <input type="checkbox">
  <span class="checkmark"></span>
</label>

<label class="container2">Database 3
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<h4>Columns</h4>
<h5>Database One</h5>
  <label class="container3">Column One
  <input type="checkbox" checked="checked">
  <span class="checkmark"></span>
</label>

<label class="container3">Column Two
  <input type="checkbox">
  <span class="checkmark"></span>
</label>

<label class="container3">Column Three
  <input type="checkbox">
  <span class="checkmark"></span>
</label>

<label class="container3">Column Four
  <input type="checkbox">
  <span class="checkmark"></span>
</label>

<!-- second column -->
<h5> Database Two </h5>
  <label class="container3">Column One
  <input type="checkbox" checked="checked">
  <span class="checkmark"></span>
</label>

<label class="container3">Column Two
  <input type="checkbox">
  <span class="checkmark"></span>
</label>

<label class="container3">Column Three
  <input type="checkbox">
  <span class="checkmark"></span>
</label>

<label class="container3">Column Four
  <input type="checkbox">
  <span class="checkmark"></span>
</label>

<h5> Database Three </h5>
  <label class="container3">Column One
  <input type="checkbox" checked="checked">
  <span class="checkmark"></span>
</label>

<label class="container3">Column Two
  <input type="checkbox">
  <span class="checkmark"></span>
</label>

<label class="container3">Column Three
  <input type="checkbox">
  <span class="checkmark"></span>
</label>

<label class="container3">Column Four
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<h4>Filters</h4>
 <button class="button button4">Add Filter</button>
 <div class="navbar">
   <div class="dropdown">
  <button class="dropbtn" onclick="myFunction()">Value
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-content" id="myDropdown">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
   <div class="dropdown">
  <button class="dropbtn" onclick="myFunction()">Columns
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-content" id="myDropdown">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
  <div class="dropdown">
  <button class="dropbtn" onclick="myFunction()">Condition
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-content" id="myDropdown">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
   <div class="dropdown">
  <button class="dropbtn" onclick="myFunction()">Tables
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-content" id="myDropdown">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
  </div> 
</div>
</div>
<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(e) {
  if (!e.target.matches('.dropbtn')) {
  var myDropdown = document.getElementById("myDropdown");
    if (myDropdown.classList.contains('show')) {
      myDropdown.classList.remove('show');
    }
  }
}
</script>
</body>
</html>
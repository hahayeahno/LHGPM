<!DOCTYPE html>

<?php
  session_start();

  if($_SERVER['REQUEST_METHOD'] = 'POST') {
    try {
      if(!array_key_exists("db", $_POST)) { //I don't really know how websites work, sorry
        throw new Exception("Haven't clicked the button yet");
      }      
      $_SESSION['db'] = $_POST['db'];
      header("location: ../Tables/tables.php");
    }
    catch (Exception $e) {}
  }
?>

<html lang="en">
<head>
<link href="normalize.css" rel="stylesheet" type="text/css">
<link href="query.css" rel="stylesheet"  type="text/css">
</head>
<body>
<header>
<a href="../Database/databases.php"><img src="../Images/cloud.png" alt="Cloud picture" height="115" width="115"></a> 
<div class="header">
  <h1>Cloud Stack Analysis Tool</h1>
</div>
</header>
<ul>
  <li><a href="../Tables/tables.php">Tables</a></li>
  <li><a href="../Queries/query.php">Queries</a></li>
  <li><a class="active" href="#import">Import</a></li>
  <li><a href="#log off">Log Off</a></li>
</ul>
<br>
<div class="container">
Please choose a database <br><br>
<form action = "" method = "post">
    <select name="db">
        <option selected="selected">Choose one</option>
        <?php
        $conn = $_SESSION['conn'];
        $result_string = '';
        $conn = mysqli_connect($_SESSION['servername'], $_SESSION['user'], $_SESSION['pass']);
        $query = "SELECT schema_name FROM information_schema.schemata WHERE schema_name
          NOT IN ('information_schema', 'mysql', 'performance_schema', 'sys')";

        $result = mysqli_query($conn, $query) or die(mysqli_error($link));
        $dbs = array();
        $dbs = array();
        while($db = mysqli_fetch_row($result))
          $dbs[] = $db[0];
        foreach ($dbs as $item){
          echo "<option value='$item'>$item</option>";
        }
        ?>
    </select>
    <input type="submit" value="Submit">
   </form>
   
  </div>
</body>
</html>

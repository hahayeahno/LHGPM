<!DOCTYPE html>
<html lang="en">
<head>
<link href="tables.css" rel="stylesheet"  type="text/css">
</head>
<body>
<header>
<a href="../Database/databases.php"><img src="../Images/cloud.png" alt="Cloud picture" height="115" width="115"></a> 
<div class="header">
  <h1>Cloud Stack Analysis Tool</h1>
</div>
</header>
<ul>
  <li><a class="active" href="tables.php">Tables</a></li>
  <li><a href="../Queries/query.php">Queries</a></li>
  <li><a href="../Import/import.php">Import</a></li>
  <li><a href="#log off">Log Off</a></li>
</ul>
<br>
<br>
<br>
   <div class="container">
   <form method = "post">
    <select name='table'>
        <option selected="selected">Choose one</option>
        <?php
        session_start();
        $conn = $_SESSION['conn'];
        $result_string = '';
        $conn = mysqli_connect($_SESSION['servername'], $_SESSION['user'], $_SESSION['pass']);
        $selectedDB = $_SESSION['db'];
        $query = "SELECT table_name FROM information_schema.tables WHERE TABLE_SCHEMA='" . $selectedDB . "';";

        $result = mysqli_query($conn, $query) or die(mysqli_error($link));
        $dbs = array();
        while($db = mysqli_fetch_row($result))
          $dbs[] = $db[0];
        foreach ($dbs as $item){
          echo "<option value='$item'>$item</option>";
        }
        ?>
    </select>
    <input type="submit" value="Submit">
   </form>
   </div>
   <style>
    table, th, td {
    border: 1px solid;
    font-size: 11px;
    }
   </style>
   <?php
    if($_SERVER['REQUEST_METHOD'] = 'POST') {
      try {
        if (!array_key_exists('table', $_POST)) {
          throw new Exception("Please select a table /\\");
        }
        $host = $_SESSION['servername'];
        $user = $_SESSION['user'];
        $pass = $_SESSION['pass'];
        $selectedDB = $_SESSION['db'];
        $selectedTable = $_POST['table'];
        //$db_name = "database_name_here";

        //create connection
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        $connection = mysqli_connect($host, $user, $pass);

        //get results from database
        $result = mysqli_query($connection, "SELECT * FROM ". $selectedDB . "." . $selectedTable . " LIMIT 500");
        $all_property = array();  //declare an array for saving property

        //showing property
        echo '<table>
                <tr>';  //initialize table tag
        while ($property = mysqli_fetch_field($result)) {
            echo '<td>' . $property->name . '</td>';  //get field name for header
            $all_property[] = $property->name;  //save those to array
        }
        echo '</tr>'; //end tr tag

        //showing all data
        while ($row = mysqli_fetch_array($result)) {
            echo "<tr>";
            foreach ($all_property as $item) {
                echo '<td>' . $row[$item] . '</td>'; //get items using property value
            }
            echo '</tr>';
        }
        echo "</table>";
      }
      catch (Exception $e) {
        // I dont know php, so I'm not sure why it's using post before anything is posted.
        // If we had more time, I would learn PHP and actual websites, but I'm tired and bitter. 
      }
    }
    ?>
    
<script> // I have no clue what this script does, it was just part of the web interface provided.
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    }
  });
}
</script>
</body>
</html>